import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { FirebaseContext } from './store/FirebaseContext';
import firebase from './firebase/config';

// Use createRoot instead of ReactDOM.render
createRoot(document.getElementById('root')).render(
  <FirebaseContext.Provider value={firebase}>
    <App />
  </FirebaseContext.Provider>
);
